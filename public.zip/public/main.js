import { initializeApp } from "https://www.gstatic.com/firebasejs/12.3.0/firebase-app.js";
import {
  getAuth,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  onAuthStateChanged,
  setPersistence,
  browserSessionPersistence,
  GoogleAuthProvider,
  signInWithPopup,
  signInWithRedirect,
  getRedirectResult,
  RecaptchaVerifier,
  PhoneAuthProvider,
  linkWithCredential
} from "https://www.gstatic.com/firebasejs/12.3.0/firebase-auth.js";

/* ---------- Config ---------- */
const firebaseConfig = {
  apiKey: "AIzaSyBe1_NlDxqE2S-7B3WGF3ty3fvK0LnZXYE",
  authDomain: "studio-8688893959-d0b06.firebaseapp.com",
  projectId: "studio-8688893959-d0b06",
  storageBucket: "studio-8688893959-d0b06.firebasestorage.app",
  messagingSenderId: "588584182816",
  appId: "1:588584182816:web:78745733ebdf27f56f4845"
};
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

/* ---------- DOM ---------- */
// Sign up
const emailEl = document.getElementById('email');
const ccEl = document.getElementById('country-code');
const phoneEl = document.getElementById('phone');
const passwordEl = document.getElementById('password');

const smsStep1 = document.getElementById('sms-step1');
const smsStep2 = document.getElementById('sms-step2');

const btnSendSms = document.getElementById('btn-send-sms');
const smsCodeEl = document.getElementById('sms-code');
const btnVerifySms = document.getElementById('btn-verify-sms');

const btnRegister = document.getElementById('btn-register');
const statusSignupEl = document.getElementById('status-signup');

// Login
const emailLoginEl = document.getElementById('email-login');
const passwordLoginEl = document.getElementById('password-login');
const btnLogin = document.getElementById('btn-login');
const btnGoogle = document.getElementById('btn-google');

// Password reqs
const reqUpper = document.getElementById('req-uppercase');
const reqSeq = document.getElementById('req-no-seq');
const reqSpec = document.getElementById('req-special');

/* ---------- Helpers ---------- */
function showStatusSignup(msg, isError = false) {
  if (!statusSignupEl) return;
  statusSignupEl.textContent = msg;
  statusSignupEl.style.color = isError ? '#ffd2d2' : '#e8ffe8';
}
function showStatusLogin(msg, isError = false) {
  const el = document.getElementById('status');
  if (!el) return;
  el.textContent = msg;
  el.style.color = isError ? '#b02a2a' : '#111';
}
function hasUppercase(s) { return /[A-Z]/.test(s || ''); }
function hasSpecialChar(s) { return /[!@#$%^&*(),.?":{}|<>[\]\\\-+_=;']/g.test(s || ''); }
function hasSequentialNumbers(str, length = 3) {
  const nums = (str || '').replace(/\D/g, '');
  if (nums.length < length) return false;
  for (let i = 0; i <= nums.length - length; i++) {
    let ok = true;
    for (let j = 1; j < length; j++) {
      if (+nums[i + j] !== +nums[i + j - 1] + 1) { ok = false; break; }
    }
    if (ok) return true;
  }
  return false;
}
function validatePasswordUI() {
  const pw = passwordEl?.value || '';
  const u = hasUppercase(pw); const s = hasSpecialChar(pw); const n = !hasSequentialNumbers(pw);
  reqUpper?.classList.toggle('valid', u); reqUpper?.classList.toggle('invalid', !u);
  reqSpec?.classList.toggle('valid', s); reqSpec?.classList.toggle('invalid', !s);
  reqSeq?.classList.toggle('valid', n); reqSeq?.classList.toggle('invalid', !n);
}
passwordEl?.addEventListener('input', validatePasswordUI);

async function ensureSessionPersistence() { try { await setPersistence(auth, browserSessionPersistence); } catch { } }
function fullPhone() {
  const cc = (ccEl?.value || '').trim();
  const ph = (phoneEl?.value || '').replace(/\s+/g, '');
  return `${cc}${ph}`;
}

// Mensajes “humanizados”
function humanizePhoneError(err) {
  const code = err?.code || '';
  if (code === 'auth/billing-not-enabled') {
    return 'Para enviar SMS habilita facturación (Blaze) o desactiva reCAPTCHA Enterprise en Authentication → Phone. En desarrollo usa números de prueba.';
  }
  if (code === 'auth/too-many-requests') return 'Demasiados intentos. Espera y vuelve a intentar (o usa un número de prueba).';
  if (code === 'auth/quota-exceeded') return 'Se superó la cuota de SMS del proyecto.';
  if (code === 'auth/invalid-phone-number') return 'Número inválido. Usa formato +57XXXXXXXXXX.';
  return (err?.message || code || 'Error desconocido');
}

/* ---------- reCAPTCHA & Phone ---------- */
let recaptchaVerifier = null;          // invisible en el botón
let phoneVerificationId = null;
let pendingPhoneCredential = null;

function initInvisibleRecaptchaOnButton() {
  if (!recaptchaVerifier) {
    recaptchaVerifier = new RecaptchaVerifier(auth, btnSendSms, { size: 'invisible' });
  }
  return recaptchaVerifier;
}

/* 1) Enviar SMS */
btnSendSms?.addEventListener('click', async () => {
  try {
    const p = fullPhone();
    if (!/^\+\d{6,15}$/.test(p)) { showStatusSignup('Teléfono inválido (usa +57XXXXXXXXXX).', true); return; }
    if (!emailEl?.value || !/^\S+@\S+\.\S+$/.test(emailEl.value)) { showStatusSignup('Ingresa un correo válido.', true); return; }
    if (!passwordEl?.value) { showStatusSignup('Ingresa una contraseña.', true); return; }

    showStatusSignup('Enviando SMS…');
    btnSendSms.disabled = true;

    const appVerifier = initInvisibleRecaptchaOnButton();
    const provider = new PhoneAuthProvider(auth);
    phoneVerificationId = await provider.verifyPhoneNumber(p, appVerifier);

    // Paso 2 visible
    smsStep1?.classList.add('hidden');
    smsStep2?.classList.remove('hidden');
    smsCodeEl?.focus();

    showStatusSignup('Código enviado por SMS. Ingresa el código y presiona Verificar.');
  } catch (err) {
    console.error('send sms', err);
    btnSendSms.disabled = false;
    showStatusSignup('No se pudo enviar el SMS: ' + humanizePhoneError(err), true);
  }
});

/* 2) Verificar código */
btnVerifySms?.addEventListener('click', async () => {
  try {
    if (!phoneVerificationId) { showStatusSignup('Primero envía el SMS.', true); return; }
    const code = (smsCodeEl?.value || '').trim();
    if (!/^\d{4,8}$/.test(code)) { showStatusSignup('Código inválido.', true); return; }

    pendingPhoneCredential = PhoneAuthProvider.credential(phoneVerificationId, code);

    // Ocultamos la etapa 2 (ya no se necesita) y habilitamos registro
    smsStep2?.classList.add('hidden');
    showStatusSignup('✅ Teléfono verificado. Presiona “Crear cuenta” para completar el registro.');
    btnRegister.disabled = false;
  } catch (err) {
    console.error('verify code', err);
    showStatusSignup('Código incorrecto o expirado.', true);
  }
});

/* 3) Registro (email/password) + enlazar teléfono verificado */
btnRegister?.addEventListener('click', async () => {
  try {
    const email = (emailEl?.value || '').trim();
    const pw = passwordEl?.value || '';

    if (!pendingPhoneCredential) {
      showStatusSignup('Verifica tu teléfono primero (envía y confirma el código).', true);
      return;
    }

    const okUpper = hasUppercase(pw);
    const okNoSeq = !hasSequentialNumbers(pw);
    const okSpec = hasSpecialChar(pw);
    validatePasswordUI();
    if (!okUpper || !okNoSeq || !okSpec) {
      showStatusSignup('La contraseña no cumple los requisitos.', true); return;
    }

    showStatusSignup('Creando cuenta…');
    await ensureSessionPersistence();
    const cred = await createUserWithEmailAndPassword(auth, email, pw);
    await linkWithCredential(cred.user, pendingPhoneCredential);

    showStatusSignup('🎉 Cuenta creada y teléfono verificado. ¡Iniciando sesión!');
  } catch (err) {
    console.error('register', err);
    showStatusSignup('Error al crear la cuenta: ' + (err.message || err.code), true);
  }
});

/* ---------- Login (email/password) ---------- */
btnLogin?.addEventListener('click', async () => {
  try {
    showStatusLogin('Iniciando sesión...');
    await ensureSessionPersistence();
    await signInWithEmailAndPassword(auth, emailLoginEl.value, passwordLoginEl.value);
    showStatusLogin('Sesión iniciada.');
  } catch (err) {
    console.error('login', err);
    showStatusLogin('Error: ' + (err.message || err.code), true);
  }
});

/* ---------- Google ---------- */
btnGoogle?.addEventListener('click', async () => {
  try {
    showStatusLogin('Iniciando sesión con Google...');
    await ensureSessionPersistence();
    const provider = new GoogleAuthProvider();
    await signInWithPopup(auth, provider);
    showStatusLogin('Sesión iniciada con Google.');
  } catch (err) {
    console.error('Google popup', err);
    const popupErrors = ['auth/popup-blocked', 'auth/popup-closed-by-user', 'auth/cancelled-popup-request'];
    if (popupErrors.includes(err.code) || err.message?.includes('popup')) {
      try {
        showStatusLogin('Abriendo redirección de Google…');
        await signInWithRedirect(auth, new GoogleAuthProvider());
      } catch (e2) {
        console.error('Google redirect', e2);
        showStatusLogin('Error Google: ' + (e2.message || e2.code), true);
      }
    } else {
      showStatusLogin('Error Google: ' + (err.message || err.code), true);
    }
  }
});

// Resultado de redirect (si hubo)
getRedirectResult(auth).catch(e => console.error('redirect result', e));

/* ---------- Redirección tras login ---------- */
onAuthStateChanged(auth, (user) => {
  if (user) {
    // después de iniciar sesión o registrarse, ir al tablero
    window.location.href = 'dashboard.html';

  } else {
    showStatusLogin('');
    // no limpiamos el de signup para conservar el estado
  }
});

/* Evitar submit por Enter (usamos botones) */
document.getElementById('form-signup')?.addEventListener('submit', e => e.preventDefault());
document.getElementById('form-login')?.addEventListener('submit', e => e.preventDefault());
