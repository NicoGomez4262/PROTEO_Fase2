// ==============================
// Firebase (modular v12 CDN)
// ==============================
import { initializeApp, getApps } from "https://www.gstatic.com/firebasejs/12.3.0/firebase-app.js";
import {
  getAuth,
  onAuthStateChanged,
  signOut
} from "https://www.gstatic.com/firebasejs/12.3.0/firebase-auth.js";
import {
  getFirestore,
  doc,
  getDoc,
  setDoc,
  updateDoc,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/12.3.0/firebase-firestore.js";

// ---------- Configuración ----------
const firebaseConfig = {
  apiKey: "AIzaSyBe1_NlDxqE2S-7B3WGF3ty3fvK0LnZXYE",
  authDomain: "studio-8688893959-d0b06.firebaseapp.com",
  projectId: "studio-8688893959-d0b06",
  storageBucket: "studio-8688893959-d0b06.firebasestorage.app",
  messagingSenderId: "588584182816",
  appId: "1:588584182816:web:78745733ebdf27f56f4845"
};

// Inicializa una sola vez y expone global para otros módulos
const app  = getApps().length ? getApps()[0] : initializeApp(firebaseConfig);
const auth = getAuth(app);
const db   = getFirestore(app);

// Disponibles por si otro módulo necesita rescate si getApp() falla
window.__APP  = app;
window.__AUTH = auth;
window.__DB   = db;

// ==============================
// Utilidades DOM
// ==============================
const $  = (sel) => document.querySelector(sel);
const $$ = (sel) => document.querySelectorAll(sel);

const setTextAll = (nodes, value) => {
  for (const el of nodes) el.textContent = value ?? "";
};

const DEFAULT_AVATAR = "assets/img/perfil-vacio.png";

// ==============================
// Firestore: helpers
// ==============================
function usernameFromEmail(email) {
  if (!email) return "";
  return (email.split("@")[0] || "").trim();
}

async function ensureUserDoc(user) {
  const ref  = doc(db, "users", user.uid);
  const snap = await getDoc(ref);

  if (!snap.exists()) {
    const payload = {
      uid: user.uid,
      email: user.email || "",
      displayName: user.displayName || usernameFromEmail(user.email),
      phone: "",
      docNumber: "",
      hotel: "Jave-Hostal",
      locker: 1,
      proteoPoints: 102,
      photoURL: user.photoURL || "",
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    };
    await setDoc(ref, payload);
    return payload;
  }

  const data = snap.data();
  const mustUpdate =
    (!data.displayName && user.email) ||
    data.email !== user.email ||
    (!data.photoURL && user.photoURL);

  if (mustUpdate) {
    await updateDoc(ref, {
      email: user.email || data.email || "",
      displayName: data.displayName || usernameFromEmail(user.email),
      photoURL: data.photoURL || user.photoURL || "",
      updatedAt: serverTimestamp()
    });
  }

  return (await getDoc(ref)).data();
}

async function saveUserDoc(uid, patch) {
  const ref = doc(db, "users", uid);
  // ❌ Antes: { .patch, updatedAt: ... }  ->  ✅ Ahora:
  await updateDoc(ref, { ...patch, updatedAt: serverTimestamp() });
  const snap = await getDoc(ref);
  return snap.data();
}

// ==============================
// Topbar & acciones globales
// ==============================
function bindTopbar(user, userDoc) {
  const chosenPhoto = userDoc?.photoURL || user?.photoURL || DEFAULT_AVATAR;

  // Avatar arriba a la derecha
  const avatarImg = $("#avatar-img");
  if (avatarImg) {
    avatarImg.src = chosenPhoto;
    avatarImg.alt = userDoc?.displayName || usernameFromEmail(user?.email) || "Avatar";
  }

  // Mini menú
  const avatarBtn = $("#avatar");
  const userMenu  = $("#user-menu");
  if (avatarBtn && userMenu) {
    let open = false;
    const toggle = () => {
      open = !open;
      userMenu.style.display = open ? "block" : "none";
    };
    avatarBtn.addEventListener("click", toggle);
    document.addEventListener("click", (e) => {
      if (!avatarBtn.contains(e.target) && !userMenu.contains(e.target)) {
        userMenu.style.display = "none";
        open = false;
      }
    });
  }

  // Logout
  const logoutBtn = $("#btn-logout");
  if (logoutBtn) {
    logoutBtn.addEventListener("click", async () => {
      try {
        await signOut(auth);
        window.location.href = "login.html";
      } catch (e) {
        console.error("logout error", e);
      }
    });
  }
}

// ==============================
// Render: PROFILE (vista)
// ==============================
function renderProfileView(user, data) {
  const displayName = data.displayName || usernameFromEmail(user.email);
  const emailToShow = user.email || data.email || "—";
  const phoneToShow = data.phone || "—";
  const docToShow   = data.docNumber || "—";
  const lockerNum   = data.locker ?? 1;

  // Nombre, teléfono y correo en todos los [data-user]
  setTextAll($$('[data-user="name"]'),  displayName);
  setTextAll($$('[data-user="phone"]'), phoneToShow);
  setTextAll($$('[data-user="email"]'), emailToShow);

  // Documento (id específico de tu HTML)
  const docOut = $("#doc-out");
  if (docOut) docOut.textContent = docToShow;

  // Badge de casillero (si existe)
  const badge = document.querySelector(".actions-right .badge");
  if (badge) badge.textContent = `Casillero #${lockerNum}`;

  // Imagen de perfil del banner
  const chosenPhoto =
    data.photoURL ||
    auth.currentUser?.photoURL ||
    DEFAULT_AVATAR;

  const profileImg = document.querySelector(".profile-photo");
  if (profileImg) {
    profileImg.src = chosenPhoto;
    profileImg.alt = displayName;
  }
}

// ==============================
// Render: PROFILE (editar)
// ==============================
function bindProfileEdit(user, data) {
  const inpName  = $("#inp-name");
  const inpPhone = $("#inp-phone");
  const inpDoc   = $("#inp-doc");
  const inpMail  = $("#inp-email"); // disabled
  const form     = $("#edit-form");

  if (inpName)  inpName.value  = data.displayName || usernameFromEmail(user.email);
  if (inpPhone) inpPhone.value = data.phone || "";
  if (inpDoc)   inpDoc.value   = data.docNumber || "";
  if (inpMail)  inpMail.value  = user.email || data.email || "";

  if (form) {
    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      try {
        const patch = {
          displayName: (inpName?.value || "").trim(),
          phone:       (inpPhone?.value || "").trim(),
          docNumber:   (inpDoc?.value || "").trim()
          // photoURL: cuando subas al Storage, lo agregamos aquí
        };
        await saveUserDoc(user.uid, patch);
        window.location.href = "profile.html";
      } catch (err) {
        console.error("update profile", err);
        alert("No se pudieron guardar los cambios.");
      }
    });
  }
}

// ==============================
// Convenios (si aplica en otras páginas)
// ==============================
function renderConvenios(data) {
  const pts = `${data.proteoPoints ?? 102}+`;
  setTextAll($$('[data-field="points"], #pts'), pts);
}

// ==============================
// Router: decide qué pintar
// ==============================
async function routeAfterAuth(user) {
  const userDoc = await ensureUserDoc(user);

  // Topbar
  bindTopbar(user, userDoc);

  // Detecta si estamos en la vista de perfil por tu HTML actual
  const isProfileView = !!(document.querySelector(".profile-photo") || document.querySelector("[data-user]"));
  if (isProfileView) {
    renderProfileView(user, userDoc);
  }

  // Si estás en página de edición (otro HTML)
  if (document.querySelector("#profile-edit")) {
    bindProfileEdit(user, userDoc);
  }

  // Convenios (si existe ese bloque en la página actual)
  if (document.querySelector(".points-banner")) {
    renderConvenios(userDoc);
  }
}

// ==============================
// Boot: sesión
// ==============================
onAuthStateChanged(auth, async (user) => {
  if (!user) {
    if (!location.pathname.endsWith("login.html")) {
      window.location.href = "login.html";
    }
    return;
  }
  try {
    await routeAfterAuth(user);
  } catch (e) {
    console.error(e);
  }
});

export { app, auth, db };
