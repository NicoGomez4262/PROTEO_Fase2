(function(){
  const href = "/assets/img/proteo-lock.png";
  let link = document.querySelector('link[rel="icon"]');
  if(!link){
    link = document.createElement('link');
    link.rel = "icon";
    link.type = "image/png";
    document.head.appendChild(link);
  }
  link.href = href;
})();
