// role-gate.js
import { auth, db } from "./app.js";
import { onAuthStateChanged } from "https://www.gstatic.com/firebasejs/12.3.0/firebase-auth.js";
import { doc, getDoc, setDoc, updateDoc, serverTimestamp } from "https://www.gstatic.com/firebasejs/12.3.0/firebase-firestore.js";

function getExpectedRole() {
  if (window.__EXPECTED_ROLE__) return window.__EXPECTED_ROLE__;
  const s = document.querySelector('script[src*="role-gate.js"][data-role]');
  return s?.dataset?.role || null;
}
const expectedRole = getExpectedRole();

const DEST_BY_ROLE = {
  client: "dashboard.html",
  host: "host-dashboard.html",
  superadmin: "superadmin-dashboard.html",
};

function goTo(role) {
  const dest = DEST_BY_ROLE[role] || DEST_BY_ROLE.client;
  const here = location.pathname.split("/").pop() || "index.html";
  if (here !== dest) location.replace(dest);
}

async function heartbeat(uid) {
  try {
    await updateDoc(doc(db, "users", uid), { lastActive: serverTimestamp() });
  } catch (e) {
    try {
      await setDoc(doc(db, "users", uid), { lastActive: serverTimestamp() }, { merge: true });
    } catch {}
  }
}

onAuthStateChanged(auth, async (u) => {
  if (!u) {
    location.href = "login.html";
    return;
  }

  let role = null;

  try {
    const token = await u.getIdTokenResult(true);
    role = token?.claims?.role || null;
  } catch (e) {
    console.warn("role-gate: no pude leer claims:", e);
  }

  if (!role) {
    try {
      const snap = await getDoc(doc(db, "users", u.uid));
      role = snap.exists() ? (snap.data()?.role || null) : null;
    } catch (e) {
      console.warn("role-gate: no pude leer users/{uid}:", e);
    }
  }

  if (!role) {
    alert("Tu cuenta no tiene rol asignado. Contacta al administrador.");
    return;
  }

  try {
    await setDoc(doc(db, "users", u.uid), {
      email: u.email || null,
      displayName: u.displayName || null,
      role
    }, { merge: true });
  } catch {}

  heartbeat(u.uid);
  setInterval(() => heartbeat(u.uid), 30000);

  if (expectedRole && expectedRole !== role) {
    goTo(role);
  } else if (!expectedRole) {
    goTo(role);
  }
});
