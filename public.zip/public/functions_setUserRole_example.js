// functions_setUserRole_example.js
// Firebase Functions v2 — Ejemplo minimal de función invocable para cambiar roles
import { onCall, HttpsError } from "firebase-functions/v2/https";
import * as admin from "firebase-admin";
admin.initializeApp();

export const setUserRole = onCall(async (request) => {
  const caller = request.auth;
  if (!caller || caller.token.role !== "superadmin") {
    throw new HttpsError("permission-denied", "Solo superadmin puede asignar roles");
  }
  const { uid, role } = request.data || {};
  if (!uid || !["client","host","superadmin"].includes(role)) {
    throw new HttpsError("invalid-argument", "Parámetros inválidos");
  }

  await admin.auth().setCustomUserClaims(uid, { role });
  await admin.firestore().doc(`users/${uid}`).set(
    { role, updatedAt: admin.firestore.FieldValue.serverTimestamp() },
    { merge: true }
  );
  return { ok: true };
});
